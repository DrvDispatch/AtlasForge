module.exports=[67222,(a,b,c)=>{}];

//# sourceMappingURL=apps_landing__next-internal_server_app_cancellation_page_actions_611a2dd0.js.map