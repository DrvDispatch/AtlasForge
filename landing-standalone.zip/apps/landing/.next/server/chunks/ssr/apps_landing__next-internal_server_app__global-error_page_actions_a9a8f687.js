module.exports=[11810,(a,b,c)=>{}];

//# sourceMappingURL=apps_landing__next-internal_server_app__global-error_page_actions_a9a8f687.js.map