module.exports=[95061,(a,b,c)=>{}];

//# sourceMappingURL=apps_landing__next-internal_server_app_promotions_page_actions_ef3df74b.js.map