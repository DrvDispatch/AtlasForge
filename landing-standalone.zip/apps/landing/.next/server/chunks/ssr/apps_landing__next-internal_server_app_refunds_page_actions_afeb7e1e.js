module.exports=[95050,(a,b,c)=>{}];

//# sourceMappingURL=apps_landing__next-internal_server_app_refunds_page_actions_afeb7e1e.js.map