module.exports=[17640,(a,b,c)=>{}];

//# sourceMappingURL=apps_landing__next-internal_server_app__not-found_page_actions_38da1d6d.js.map