module.exports=[84474,(a,b,c)=>{}];

//# sourceMappingURL=apps_landing__next-internal_server_app_contact_page_actions_99a70fec.js.map