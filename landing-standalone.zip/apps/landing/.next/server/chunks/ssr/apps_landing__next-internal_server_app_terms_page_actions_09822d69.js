module.exports=[38095,(a,b,c)=>{}];

//# sourceMappingURL=apps_landing__next-internal_server_app_terms_page_actions_09822d69.js.map