module.exports=[55828,(a,b,c)=>{}];

//# sourceMappingURL=apps_landing__next-internal_server_app_page_actions_1229341f.js.map